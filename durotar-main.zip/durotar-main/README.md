# Durotar town mod for VCMI

New Durotar town.

To rebalance skills, heroes, etc., checkout: https://github.com/vdhan/an-expansion

To calculates AI and Fight Values of creatures, checkout: https://github.com/vdhan/an-balancer

To extract Heroes 3 .lod files, checkout: https://github.com/vdhan/extract-lod

Software development kit: https://grayface.github.io/wog/

Contact me: https://vudachoangan.com/